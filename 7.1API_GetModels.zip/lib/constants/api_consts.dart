String BASE_URL = "https://api.openai.com/v1";
String API_KEY = "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";