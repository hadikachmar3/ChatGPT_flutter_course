String BASE_URL = "https://api.openai.com/v1";
String API_KEY = "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";