String BASE_URL = "https://api.openai.com/v1";
String API_KEY = "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";
