String BASE_URL = "https://api.openai.com/v1";
String API_KEY = "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";